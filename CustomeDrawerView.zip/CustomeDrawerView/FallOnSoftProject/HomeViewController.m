//
//  HomeViewController.m
//  FallOnSoftProject
//
//  Created by Kumar on 10/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "HomeViewController.h"
#import "HeaderView.h"
#import "LeftDrawerView.h"
#import "RightDrawerView.h"

@interface HomeViewController ()<HeaderViewDelegates>

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    [self navigationView];
}

-(void) navigationView
{
    HeaderView *navigationBar = [[[NSBundle mainBundle] loadNibNamed:@"HeaderView" owner:self options:nil] objectAtIndex:0];
    navigationBar.headerTitle.text=@"Product";
    navigationBar.delegate=self;
    [self.view addSubview:navigationBar];
    
}
-(void)clickLeftDrawer
{
    LeftDrawerView  *  drawerView = [[[NSBundle mainBundle] loadNibNamed:@"LeftDrawerView" owner:self options:nil] objectAtIndex:0];
    //  [drawerView setDelegate:(id<LeftDrawerViewDelegate>)self];
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5;
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [drawerView.layer addAnimation:transition forKey:nil];
    [self.view addSubview:drawerView];
}
-(void)clickRightDrawer
{
    RightDrawerView    *  drawerView = [[[NSBundle mainBundle] loadNibNamed:@"RightDrawerView" owner:self options:nil] objectAtIndex:0];
    
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5;
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [drawerView.layer addAnimation:transition forKey:nil];
    [self.view addSubview:drawerView];
}

@end
