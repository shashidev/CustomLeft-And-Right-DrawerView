//
//  RightDrawerView.m
//  FallOnSoftProject
//
//  Created by Kumar on 17/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "RightDrawerView.h"

@implementation RightDrawerView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    CGRect screen=[[UIScreen mainScreen]bounds];
    self.frame=screen;
    
    self.menuItems=[[NSMutableArray alloc]initWithObjects:@"Product",@"Home",@"Fruits",@"Events",@"Gift", nil];
    [self.rightTableView reloadData];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.menuItems count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if(!cell)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    
    cell.textLabel.text=[self.menuItems objectAtIndex:indexPath.row];
    return cell;
    
}
- (IBAction)hideRightDrawer:(id)sender {
    [self highlightLetter];
}
-(void)highlightLetter
{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGRect napkinBottomFrame = screenRect;
    napkinBottomFrame.origin.x = +(self.frame.size.width);
    [UIView animateWithDuration:0.5 delay:0.0 options: UIViewAnimationOptionCurveEaseOut animations:^{ self.frame = napkinBottomFrame; } completion:^(BOOL finished){/*done*/
        
        [self removeFromSuperview];
        
    }];
    
}
@end
