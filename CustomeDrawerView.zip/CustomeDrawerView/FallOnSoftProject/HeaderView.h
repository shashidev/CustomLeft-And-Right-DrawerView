//
//  HeaderView.h
//  FallOnSoftProject
//
//  Created by Kumar on 10/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol HeaderViewDelegates
- (void)clickLeftDrawer;
-(void)clickRightDrawer;
@end
@interface HeaderView : UIView
@property (strong, nonatomic) IBOutlet UILabel *headerTitle;
- (IBAction)menuButton:(id)sender;
- (IBAction)rightMenuButton:(id)sender;

@property (nonatomic, retain) id <HeaderViewDelegates> delegate;
@end
