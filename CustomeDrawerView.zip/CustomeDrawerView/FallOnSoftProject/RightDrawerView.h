//
//  RightDrawerView.h
//  FallOnSoftProject
//
//  Created by Kumar on 17/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RightDrawerView : UIView<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,retain)NSMutableArray *menuItems;
- (IBAction)hideRightDrawer:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *rightTableView;

@end
