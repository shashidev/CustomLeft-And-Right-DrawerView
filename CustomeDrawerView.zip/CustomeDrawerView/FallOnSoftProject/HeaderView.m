//
//  HeaderView.m
//  FallOnSoftProject
//
//  Created by Kumar on 10/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "HeaderView.h"

@implementation HeaderView

- (void) setDelegate:(id)newDelegate{
    _delegate = newDelegate;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (IBAction)menuButton:(id)sender {
    
    [self.delegate clickLeftDrawer];
    
}

- (IBAction)rightMenuButton:(id)sender {
    [self.delegate clickRightDrawer];
}
@end
