//
//  PopUpView.h
//  FallOnSoftProject
//
//  Created by Kumar on 10/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PopUpView : UIView
@property (strong, nonatomic) IBOutlet UILabel *tempLabel;
@property(nonatomic,retain)NSString *strTemp;
- (IBAction)hidePopUp:(id)sender;
@end
