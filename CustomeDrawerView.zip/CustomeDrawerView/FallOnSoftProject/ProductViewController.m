//
//  ViewController.m
//  FallOnSoftProject
//
//  Created by Kumar on 10/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "ProductViewController.h"
#import "HeaderView.h"
#import "RightDrawerView.h"
#import "LeftDrawerView.h"
#import "PopUpView.h"

@interface ProductViewController ()<HeaderViewDelegates,UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *myTableView;

@end

@implementation ProductViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self navigationView];
    
}

-(void) navigationView
{
    HeaderView *navigationBar = [[[NSBundle mainBundle] loadNibNamed:@"HeaderView" owner:self options:nil] objectAtIndex:0];
    navigationBar.headerTitle.text=@"Product";
    navigationBar.delegate=self;
    [self.view addSubview:navigationBar];

}
-(void)clickLeftDrawer
{
    LeftDrawerView  *  drawerView = [[[NSBundle mainBundle] loadNibNamed:@"LeftDrawerView" owner:self options:nil] objectAtIndex:0];
 
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5;
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromLeft;
    [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [drawerView.layer addAnimation:transition forKey:nil];
    [self.view addSubview:drawerView];
}

-(void)clickRightDrawer
{
    RightDrawerView    *  drawerView = [[[NSBundle mainBundle] loadNibNamed:@"RightDrawerView" owner:self options:nil] objectAtIndex:0];
   
    CATransition *transition = [CATransition animation];
    transition.duration = 0.5;
    transition.type = kCATransitionPush;
    transition.subtype = kCATransitionFromRight;
    [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    [drawerView.layer addAnimation:transition forKey:nil];
    [self.view addSubview:drawerView];
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(!cell)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        
    }
    
    cell.textLabel.text=[NSString stringWithFormat:@"Cell At Index : %ld",(long)indexPath.row];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    PopUpView *popUp = [[[NSBundle mainBundle] loadNibNamed:@"PopUpView" owner:self options:nil] objectAtIndex:0];
    CATransition *transition=[CATransition animation];
    transition.type=kCATransitionPush;
    transition.subtype=kCATransitionFromBottom;
    transition.duration=0.5;
    [transition setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut]];
    [popUp.layer addAnimation:transition forKey:nil];
    
    popUp.strTemp=[NSString stringWithFormat:@"You clicked at : %ldth cell",(long)indexPath.row];
  
    [self.view addSubview:popUp];

}






@end
