//
//  LeftDrawerView.h
//  FallOnSoftProject
//
//  Created by Kumar on 10/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftDrawerView : UIView<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,retain)NSArray *menuItems;
@property (strong, nonatomic) IBOutlet UITableView *menuTableView;

@end
