//
//  PopUpView.m
//  FallOnSoftProject
//
//  Created by Kumar on 10/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "PopUpView.h"

@implementation PopUpView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    CGRect screen=[[UIScreen mainScreen]bounds];
    self.frame=screen;
    
    self.tempLabel.text=_strTemp;
}



- (IBAction)hidePopUp:(id)sender {
    
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGRect napkinBottomFrame = screenRect;
    napkinBottomFrame.origin.y = -(self.frame.size.height);
    [UIView animateWithDuration:0.5 delay:0.0 options: UIViewAnimationOptionCurveEaseOut animations:^{ self.frame = napkinBottomFrame; } completion:^(BOOL finished){/*done*/
        
        [self removeFromSuperview];
        
    }];
}
@end
