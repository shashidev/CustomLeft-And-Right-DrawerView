//
//  LeftDrawerView.m
//  FallOnSoftProject
//
//  Created by Kumar on 10/05/16.
//  Copyright © 2016 Kumar. All rights reserved.
//

#import "LeftDrawerView.h"

@implementation LeftDrawerView


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    
    CGRect screen=[[UIScreen mainScreen]bounds];
    self.frame=screen;
    
    self.menuItems=[[NSArray alloc]initWithObjects:@"Product",@"Home",@"Fruits",@"Events",@"Gift", nil];
    [self.menuTableView reloadData];
    
}


-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
  return   [self.menuItems count];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
    if(!cell)
    {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        
    }
    cell.textLabel.text=[self.menuItems objectAtIndex:indexPath.row];
    cell.backgroundColor=[UIColor grayColor];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self highlightLetter];
    
    UIViewController *viewController=[self viewController];
    if(viewController)
    {
        UIStoryboard *storyboard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        UIViewController *viewControllerObject;
        if(indexPath.row==0)
        {
            viewControllerObject=[storyboard instantiateViewControllerWithIdentifier:@"ProductView"];
        }
        else if(indexPath.row==1)
        {
            viewControllerObject = [storyboard instantiateViewControllerWithIdentifier:@"HomeView"];
        }
        
        if ([viewController class] != [viewControllerObject class]) {
            [viewController.navigationController pushViewController:viewControllerObject animated:NO];
        }
    }
    
   
}


-(void)highlightLetter
{
    CGRect screenRect = [[UIScreen mainScreen] bounds];
    CGRect napkinBottomFrame = screenRect;
    napkinBottomFrame.origin.x = -(self.frame.size.width);
    [UIView animateWithDuration:0.5 delay:0.0 options: UIViewAnimationOptionCurveEaseOut animations:^{ self.frame = napkinBottomFrame; } completion:^(BOOL finished){/*done*/
        
        [self removeFromSuperview];
        
    }];
    
}
- (IBAction)hideDrawer:(id)sender {
    
    [self highlightLetter];

}
- (UIViewController*)viewController
{
    for (UIView* next = [self superview]; next; next = next.superview)
    {
        UIResponder* nextResponder = [next nextResponder];
        
        if ([nextResponder isKindOfClass:[UIViewController class]])
        {
            return (UIViewController*)nextResponder;
        }
    }
    
    return nil;
}


@end
